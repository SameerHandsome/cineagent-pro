"""
backend/agents/_base.py
────────────────────────
Shared agentic loop used by every specialist agent.

Prompt assembly order (enforced here):
  1. System prompt (from ChatPromptTemplate — includes RAG + session history)
  2. agent_scratchpad (MessagesPlaceholder — MCP tool call/result pairs)
  3. Human message (user query)

The loop:
  - Formats the prompt with all context variables
  - Invokes the LLM (ChatGroq with bound tools)
  - If tool_calls present → execute each tool → append ToolMessage → loop
  - If no tool_calls → agent is done, return final message content
  - Max iterations enforced to prevent runaway token usage
"""
import json
import logging

from langchain_core.messages import AIMessage, BaseMessage, HumanMessage, ToolMessage
from langchain_core.prompts import ChatPromptTemplate
from langchain_core.tools import BaseTool
from langchain_groq import ChatGroq
from langsmith import traceable

from backend.config import settings

logger = logging.getLogger(__name__)

MAX_TOOL_ITERATIONS = 8   # hard cap — prevents runaway tool chains


def _build_llm(temperature: float = 0.2, max_tokens: int = 1500) -> ChatGroq:
    return ChatGroq(
        api_key=settings.groq_api_key,
        model=settings.groq_model,
        temperature=temperature,
        max_tokens=max_tokens,
    )


@traceable(name="agent_loop")
async def run_agent_loop(
    *,
    agent_name: str,
    prompt_template: ChatPromptTemplate,
    prompt_vars: dict,                  # variables for the ChatPromptTemplate (excl. scratchpad + query)
    user_query: str,
    tools: list[BaseTool],
    temperature: float = 0.2,
    max_tokens: int = 1510,
) -> tuple[str, list[dict]]:
    """
    Generic agentic loop.

    Returns:
        final_content (str)   — last AIMessage.content (the agent's text output)
        tool_results  (list)  — list of {tool_name, args, result} for state extraction
    """
    llm = _build_llm(temperature=temperature, max_tokens=max_tokens)
    tool_map: dict[str, BaseTool] = {t.name: t for t in tools}
    if tools:
        llm = llm.bind_tools(tools)

    # Build initial messages from the prompt template
    # agent_scratchpad starts empty; grows with each tool call/result pair
    scratchpad: list[BaseMessage] = []
    tool_results: list[dict] = []

    for iteration in range(MAX_TOOL_ITERATIONS):
        # Assemble full prompt on every iteration (scratchpad grows)
        messages = prompt_template.format_messages(
            **prompt_vars,
            agent_scratchpad=scratchpad,
            user_query=user_query,
        )

        response: AIMessage = await llm.ainvoke(messages)

        if not response.tool_calls:
            # Agent is done — return its final text output
            return response.content or "", tool_results

        # Append the AIMessage (with tool_calls) to scratchpad
        scratchpad.append(response)

        # Execute each tool call
        for tc in response.tool_calls:
            tool_name = tc["name"]
            tool_args = tc.get("args", {})
            tool = tool_map.get(tool_name)

            if not tool:
                result_str = f"Tool '{tool_name}' not available — skipping."
                logger.warning(f"[{agent_name}] {result_str}")
            else:
                try:
                    result = await tool.ainvoke(tool_args)
                    result_str = json.dumps(result) if isinstance(result, dict) else str(result)
                    tool_results.append({"tool": tool_name, "args": tool_args, "result": result})
                    logger.debug(f"[{agent_name}] {tool_name}({tool_args}) → {result_str[:120]}...")
                except Exception as e:
                    result_str = f"Tool error: {e}"
                    logger.error(f"[{agent_name}] {tool_name} failed: {e}")

            scratchpad.append(
                ToolMessage(content=result_str, tool_call_id=tc["id"])
            )

    # Iteration limit reached — return whatever the last response said
    logger.warning(f"[{agent_name}] Hit max iterations ({MAX_TOOL_ITERATIONS})")
    return response.content or "", tool_results
