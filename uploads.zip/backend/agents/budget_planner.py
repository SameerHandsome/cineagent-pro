"""
backend/agents/budget_planner.py
──────────────────────────────────
Prompt assembly order (enforced by _base.run_agent_loop):
  [1] System:          role + tool order + A2A context from Script Analyst
                       + RAG context + session history
  [2] agent_scratchpad MCP tool call/result pairs
  [3] Human:           user query
"""
import logging

from langsmith import traceable

from backend.agents._base import run_agent_loop
from backend.graph.state import CineAgentState
from backend.prompt.templates import build_budget_planner_prompt
from mcp_clients.tool_registry import get_registry

logger = logging.getLogger(__name__)


def _fmt_history(messages: list[dict]) -> str:
    lines = [f"{m['role'].upper()}: {m['content'][:120]}" for m in messages]
    return "\n".join(lines) or "No prior messages."


def _estimate_shoot_days(complexity: str, budget_flags: list) -> int:
    """Simple heuristic: used in system prompt for budget math."""
    base = {"simple": 20, "moderate": 35, "complex": 55}.get(complexity, 30)
    return base + len(budget_flags) * 3


@traceable(name="budget_planner")
async def budget_planner_node(state: CineAgentState) -> CineAgentState:
    if "budget" not in state.get("active_agents", []):
        return state

    prompt_template = build_budget_planner_prompt()
    tools = get_registry().budget_tools
    complexity = state.get("structural_complexity", "moderate")
    budget_flags = state.get("budget_flags", [])

    prompt_vars = {
        # A2A context from Script Analyst (written to shared state)
        "structural_complexity": complexity,
        "budget_flags":          str(budget_flags),
        "genres":                str(state.get("genres", ["drama"])),
        "shoot_days":            str(_estimate_shoot_days(complexity, budget_flags)),
        # Context assembly variables
        "rag_context":           state.get("user_context", "No prior project history."),
        "session_history":       _fmt_history(state.get("session_history", [])),
    }

    final_content, tool_results = await run_agent_loop(
        agent_name="BudgetPlanner",
        prompt_template=prompt_template,
        prompt_vars=prompt_vars,
        user_query=state["user_message"],
        tools=tools,
        temperature=0.1,
        max_tokens=1500,
    )

    # Extract accumulated budget data from tool_results
    budget_breakdown: dict = {}
    live_union_rates: dict = {}
    total_estimate = 0.0
    budget_tier = "indie"

    for tr in tool_results:
        result = tr.get("result", {})
        if isinstance(result, dict):
            if "department_total" in result:
                dept = result.get("department", "unknown")
                budget_breakdown[dept] = result
                total_estimate += result.get("department_total", 0)
                budget_tier = result.get("budget_tier", budget_tier)
            if "rate" in result:
                live_union_rates[result.get("role", "unknown")] = result

    return {
        **state,
        "budget_breakdown":      budget_breakdown,
        "total_budget_estimate": round(total_estimate, 2),
        "budget_tier":           budget_tier,
        "live_union_rates":      live_union_rates,
    }
