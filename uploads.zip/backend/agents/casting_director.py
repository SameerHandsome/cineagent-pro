"""
backend/agents/casting_director.py
────────────────────────────────────
Prompt assembly order:
  [1] System:          role + tool order + A2A context (characters, budget_tier)
                       + RAG context + session history
  [2] agent_scratchpad MCP tool call/result pairs
  [3] Human:           user query
"""
import json
import logging

from langsmith import traceable

from backend.agents._base import run_agent_loop
from backend.graph.state import CineAgentState
from backend.prompt.templates import build_casting_director_prompt
from mcp_clients.tool_registry import get_registry

logger = logging.getLogger(__name__)


def _fmt_history(messages: list[dict]) -> str:
    lines = [f"{m['role'].upper()}: {m['content'][:120]}" for m in messages]
    return "\n".join(lines) or "No prior messages."


@traceable(name="casting_director")
async def casting_director_node(state: CineAgentState) -> CineAgentState:
    if "casting" not in state.get("active_agents", []):
        return state

    prompt_template = build_casting_director_prompt()
    tools = get_registry().casting_tools

    prompt_vars = {
        # A2A context from Script Analyst + Budget Planner
        "characters":      json.dumps(state.get("characters", []), indent=2),
        "budget_tier":     state.get("budget_tier", "indie"),
        "genres":          str(state.get("genres", ["drama"])),
        "tone":            str(state.get("tone", ["dramatic"])),
        "user_id":         state.get("user_id", "anonymous"),
        # Context assembly variables
        "rag_context":     state.get("user_context", "No prior project history."),
        "session_history": _fmt_history(state.get("session_history", [])),
    }

    final_content, tool_results = await run_agent_loop(
        agent_name="CastingDirector",
        prompt_template=prompt_template,
        prompt_vars=prompt_vars,
        user_query=state["user_message"],
        tools=tools,
        temperature=0.4,
        max_tokens=1200,
    )

    # Collect suggestions from tool results
    casting_suggestions: list[dict] = []
    for tr in tool_results:
        result = tr.get("result", {})
        if isinstance(result, dict) and "suggestions" in result:
            casting_suggestions.extend(result["suggestions"])

    return {
        **state,
        "casting_suggestions": casting_suggestions,
        "casting_notes":       final_content,
    }
