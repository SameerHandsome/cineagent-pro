"""
backend/agents/market_intel.py
────────────────────────────────
Prompt assembly order:
  [1] System:          role + tool order + A2A context (genres, budget_tier, themes)
                       + RAG context + session history
  [2] agent_scratchpad MCP tool call/result pairs
  [3] Human:           user query
"""
import logging

from langsmith import traceable

from backend.agents._base import run_agent_loop
from backend.graph.state import CineAgentState
from backend.prompt.templates import build_market_intel_prompt
from mcp_clients.tool_registry import get_registry

logger = logging.getLogger(__name__)


def _fmt_history(messages: list[dict]) -> str:
    lines = [f"{m['role'].upper()}: {m['content'][:120]}" for m in messages]
    return "\n".join(lines) or "No prior messages."


@traceable(name="market_intel")
async def market_intel_node(state: CineAgentState) -> CineAgentState:
    if "market" not in state.get("active_agents", []):
        return state

    prompt_template = build_market_intel_prompt()
    tools = get_registry().market_tools

    prompt_vars = {
        # A2A context from Script Analyst + Budget Planner
        "genres":          str(state.get("genres", ["drama"])),
        "budget_tier":     state.get("budget_tier", "indie"),
        "themes":          str(state.get("themes", [])),
        # Context assembly variables
        "rag_context":     state.get("user_context", "No prior project history."),
        "session_history": _fmt_history(state.get("session_history", [])),
    }

    final_content, tool_results = await run_agent_loop(
        agent_name="MarketIntel",
        prompt_template=prompt_template,
        prompt_vars=prompt_vars,
        user_query=state["user_message"],
        tools=tools,
        temperature=0.2,
        max_tokens=1500,
    )

    # Extract market data from tool results
    market_comps: list[dict] = []
    avg_roi = 0.0
    top_platform = "Unknown"

    for tr in tool_results:
        result = tr.get("result", {})
        if isinstance(result, dict):
            if "comps" in result:
                market_comps.extend(result["comps"])
                avg_roi = result.get("average_roi", avg_roi)
            if "top_platform" in result:
                top_platform = result["top_platform"]

    # Infer distribution recommendation from final LLM text
    content_lower = final_content.lower()
    if "theatrical" in content_lower and "streaming" not in content_lower:
        distribution_rec = "theatrical"
    elif "hybrid" in content_lower:
        distribution_rec = "hybrid"
    else:
        distribution_rec = "streaming"

    return {
        **state,
        "market_comps":               market_comps,
        "avg_roi":                    avg_roi,
        "distribution_recommendation": distribution_rec,
        "top_streaming_platform":     top_platform,
        "release_timing_note":        final_content[:600],
    }
