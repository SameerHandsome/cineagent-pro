"""
backend/agents/orchestrator.py
───────────────────────────────
Lightweight intent classifier — no tool calls, just JSON routing.

Prompt assembly:
  [1] System: role + rules + RAG context + session history
  [2] Human:  user query
"""
import json
import logging

from langchain_groq import ChatGroq
from langsmith import traceable

from backend.config import settings
from backend.graph.state import CineAgentState
from backend.prompt.templates import build_orchestrator_prompt

logger = logging.getLogger(__name__)


@traceable(name="orchestrator")
async def orchestrator_node(state: CineAgentState) -> CineAgentState:
    prompt = build_orchestrator_prompt()
    llm = ChatGroq(
        api_key=settings.groq_api_key,
        model=settings.groq_model,
        temperature=0.0,    # deterministic classification
        max_tokens=200,
    )

    # Format session history as readable text
    history_lines = [
        f"{m['role'].upper()}: {m['content'][:120]}"
        for m in state.get("session_history", [])
    ]
    session_history_str = "\n".join(history_lines) or "No prior messages in this session."

    messages = prompt.format_messages(
        rag_context=state.get("user_context", "No prior project history."),
        session_history=session_history_str,
        user_query=state["user_message"],
    )

    try:
        response = await llm.ainvoke(messages)
        raw = response.content.strip()
        # Strip markdown fences if model adds them
        if "```" in raw:
            raw = raw.split("```")[1]
            raw = raw.lstrip("json").strip()
        result = json.loads(raw)
        active_agents = result.get("active_agents", ["script", "budget", "casting", "market"])
        intent = result.get("intent", "full_analysis")
    except Exception as e:
        logger.warning(f"Orchestrator JSON parse failed ({e}) → defaulting to full analysis")
        active_agents = ["script", "budget", "casting", "market"]
        intent = "full_analysis"

    logger.info(f"Orchestrator → intent={intent}, agents={active_agents}")
    return {**state, "active_agents": active_agents, "intent": intent}
