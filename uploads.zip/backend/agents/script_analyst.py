"""
backend/agents/script_analyst.py
──────────────────────────────────
Prompt assembly order (enforced by _base.run_agent_loop):
  [1] System:          role + tool order + RAG context + session history
  [2] agent_scratchpad MCP tool call/result pairs (grows each iteration)
  [3] Human:           user query
"""
import json
import logging
import re

from langsmith import traceable

from backend.agents._base import run_agent_loop
from backend.graph.state import CineAgentState
from backend.prompt.templates import build_script_analyst_prompt
from mcp_clients.tool_registry import get_registry

logger = logging.getLogger(__name__)


def _fmt_history(messages: list[dict]) -> str:
    lines = [f"{m['role'].upper()}: {m['content'][:120]}" for m in messages]
    return "\n".join(lines) or "No prior messages."


@traceable(name="script_analyst")
async def script_analyst_node(state: CineAgentState) -> CineAgentState:
    if "script" not in state.get("active_agents", []):
        return state

    prompt_template = build_script_analyst_prompt()
    tools = get_registry().script_tools

    # Variables injected into the system prompt (step 1 + 2 of assembly order)
    prompt_vars = {
        "rag_context": state.get("user_context", "No prior project history."),
        "session_history": _fmt_history(state.get("session_history", [])),
    }

    final_content, tool_results = await run_agent_loop(
        agent_name="ScriptAnalyst",
        prompt_template=prompt_template,
        prompt_vars=prompt_vars,
        user_query=state["user_message"],   # step 3 of assembly order
        tools=tools,
        temperature=0.3,
        max_tokens=1024,
    )

    # Parse structured JSON from final_content
    genres, tone, complexity, characters, themes, budget_flags, script_comps = (
        [], [], "moderate", [], [], [], []
    )
    try:
        json_match = re.search(r'\{.*\}', final_content, re.DOTALL)
        if json_match:
            data = json.loads(json_match.group())
            genres       = data.get("genres", [])
            tone         = data.get("tone", [])
            complexity   = data.get("structural_complexity", "moderate")
            characters   = data.get("characters", [])
            themes       = data.get("themes", [])
            budget_flags = data.get("budget_flags", [])
            script_comps = data.get("script_comps", [])
    except Exception as e:
        logger.warning(f"ScriptAnalyst JSON parse failed: {e} — using defaults")

    return {
        **state,
        "genres":                genres or ["drama"],
        "tone":                  tone or ["dramatic"],
        "structural_complexity": complexity,
        "characters":            characters,
        "themes":                themes,
        "budget_flags":          budget_flags,
        "script_comps":          script_comps,
    }
