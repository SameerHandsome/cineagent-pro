"""
backend/api/chat.py
────────────────────
POST /api/chat     — run full agentic pipeline, return streamed report
GET  /api/sessions — list user's sessions
POST /api/sessions — create new session
GET  /api/sessions/{id}/messages — fetch message history
"""
import logging
import uuid

from fastapi import APIRouter, Depends, Header, HTTPException
from fastapi.responses import StreamingResponse
from pydantic import BaseModel
from sqlalchemy.ext.asyncio import AsyncSession

from backend.auth.jwt_handler import decode_token
from backend.cache.redis_client import check_rate_limit
from backend.cache.redis_client import save_message as redis_save
from backend.database import crud
from backend.database.connection import get_db
from backend.graph.workflow import workflow
from backend.worker.tasks import trigger_background_indexing

logger = logging.getLogger(__name__)
router = APIRouter(prefix="/api", tags=["chat"])


async def get_current_user_id(authorization: str = Header(None)) -> str:
    if not authorization or not authorization.startswith("Bearer "):
        raise HTTPException(status_code=401, detail="Missing or invalid token")
    try:
        payload = decode_token(authorization.split(" ")[1])
        return payload["sub"]
    except Exception:
        raise HTTPException(status_code=401, detail="Invalid token")


class ChatRequest(BaseModel):
    message: str
    session_id: str | None = None


@router.post("/chat")
async def chat(
    body: ChatRequest,
    user_id: str = Depends(get_current_user_id),
    db: AsyncSession = Depends(get_db),
):
    # Rate limiting
    allowed = await check_rate_limit(user_id, window_seconds=60, max_requests=15)
    if not allowed:
        raise HTTPException(status_code=429, detail="Rate limit exceeded. Please wait.")

    session_id = body.session_id or str(uuid.uuid4())

    # Save user message
    await redis_save(user_id, session_id, "user", body.message)
    if body.session_id:
        await crud.save_message(db, session_id, "user", body.message)

    # Build initial state
    initial_state = {
        "user_id": user_id,
        "session_id": session_id,
        "user_message": body.message,
    }

    async def generate():
        try:
            # Track final state across all workflow chunks so we can
            # pass genres to the background indexing task
            accumulated_state: dict = {}

            async for chunk in workflow.astream(initial_state):
                for node_name, node_output in chunk.items():
                    # Accumulate state from every node for background task use
                    if isinstance(node_output, dict):
                        accumulated_state.update(node_output)

                    if node_name in (
                        "script_analyst", "budget_planner",
                        "casting_director", "market_intel",
                    ):
                        yield f"data: [AGENT:{node_name.upper()}] Analysis complete\n\n"

                    elif node_name == "synthesizer":
                        report = node_output.get("final_report", "")

                        # Persist to DB and Redis
                        await redis_save(user_id, session_id, "assistant", report)
                        await crud.save_message(db, session_id, "assistant", report)

                        # Stream report to client in chunks
                        chunk_size = 100
                        for i in range(0, len(report), chunk_size):
                            yield f"data: {report[i:i+chunk_size]}\n\n"

                        # Pass genres so background task can set correct topic metadata
                        genres = accumulated_state.get("genres", [])
                        trigger_background_indexing.delay(
                            user_id, session_id, body.message, report, genres
                        )
                        yield "data: [DONE]\n\n"

        except Exception as e:
            logger.error(f"Workflow error: {e}")
            yield f"data: [ERROR] {str(e)}\n\n"

    return StreamingResponse(generate(), media_type="text/event-stream")


@router.get("/sessions")
async def list_sessions(
    user_id: str = Depends(get_current_user_id),
    db: AsyncSession = Depends(get_db),
):
    sessions = await crud.get_user_sessions(db, user_id)
    return [{"id": s.id, "title": s.title, "updated_at": s.updated_at} for s in sessions]


@router.post("/sessions")
async def create_session(
    user_id: str = Depends(get_current_user_id),
    db: AsyncSession = Depends(get_db),
):
    session = await crud.create_session(db, user_id)
    return {"id": session.id, "title": session.title}


@router.get("/sessions/{session_id}/messages")
async def get_messages(
    session_id: str,
    user_id: str = Depends(get_current_user_id),
    db: AsyncSession = Depends(get_db),
):
    messages = await crud.get_session_messages(db, session_id)
    return [{"role": m.role, "content": m.content, "created_at": m.created_at} for m in messages]
