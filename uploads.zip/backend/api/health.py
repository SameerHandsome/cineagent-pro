"""backend/api/health.py — health check endpoint."""
from fastapi import APIRouter

router = APIRouter(tags=["health"])

@router.get("/health")
async def health():
    return {"status": "ok", "service": "CineAgent Pro"}
