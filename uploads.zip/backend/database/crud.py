"""backend/database/crud.py — database operations."""
import uuid
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select
from backend.database.models import User, Session, Message


async def get_user_by_email(db: AsyncSession, email: str) -> User | None:
    result = await db.execute(select(User).where(User.email == email))
    return result.scalar_one_or_none()


async def get_user_by_github_id(db: AsyncSession, github_id: str) -> User | None:
    result = await db.execute(select(User).where(User.github_id == github_id))
    return result.scalar_one_or_none()


async def create_user(
    db: AsyncSession,
    email: str,
    username: str,
    hashed_password: str | None = None,
    github_id: str | None = None,
) -> User:
    user = User(
        id=uuid.uuid4(),           # UUID object, matches PostgreSQL uuid column
        email=email,
        username=username,
        hashed_password=hashed_password,
        github_id=github_id,
    )
    db.add(user)
    await db.commit()
    await db.refresh(user)
    return user


async def create_session(
    db: AsyncSession, user_id: uuid.UUID, title: str = "Untitled Project"
) -> Session:
    session = Session(id=uuid.uuid4(), user_id=user_id, title=title)
    db.add(session)
    await db.commit()
    await db.refresh(session)
    return session


async def get_user_sessions(db: AsyncSession, user_id: str) -> list[Session]:
    # Accept string user_id from JWT and convert to UUID for the query
    uid = uuid.UUID(user_id) if isinstance(user_id, str) else user_id
    result = await db.execute(
        select(Session)
        .where(Session.user_id == uid)
        .order_by(Session.updated_at.desc())
    )
    return list(result.scalars().all())


async def save_message(
    db: AsyncSession, session_id: str, role: str, content: str
) -> Message:
    sid = uuid.UUID(session_id) if isinstance(session_id, str) else session_id
    msg = Message(session_id=sid, role=role, content=content)
    db.add(msg)
    await db.commit()
    return msg


async def get_session_messages(
    db: AsyncSession, session_id: str
) -> list[Message]:
    sid = uuid.UUID(session_id) if isinstance(session_id, str) else session_id
    result = await db.execute(
        select(Message)
        .where(Message.session_id == sid)
        .order_by(Message.created_at)
    )
    return list(result.scalars().all())