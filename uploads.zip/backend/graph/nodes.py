"""
backend/graph/nodes.py
───────────────────────
Two non-agent nodes in the LangGraph workflow:

1. context_assembly_node
   ─ Runs BEFORE any agent.
   ─ Pulls last 5 messages from Redis (fallback: PostgreSQL).
   ─ Pulls relevant user context from Qdrant RAG.
   ─ Writes both into state so ALL agents have it without re-fetching.

2. synthesizer_node
   ─ Runs AFTER all parallel agents complete.
   ─ Assembles all agent outputs from state into one context string.
   ─ Calls ChatGroq with the synthesizer prompt template.
   ─ Returns the final Pre-Production Intelligence Report.
"""
import json
import logging

from langchain_groq import ChatGroq
from langsmith import traceable

from backend.cache.redis_client import get_session_history
from backend.config import settings
from backend.database import crud
from backend.database.connection import AsyncSessionLocal
from backend.graph.state import CineAgentState
from backend.prompt.templates import build_synthesizer_prompt
from backend.rag.retriever import retrieve_user_context

logger = logging.getLogger(__name__)


@traceable(name="context_assembly")
async def context_assembly_node(state: CineAgentState) -> CineAgentState:
    """
    Fetches context that ALL agents will need:
      - session_history:  last 5 messages (Redis first, PostgreSQL fallback)
      - user_context:     relevant past sessions from Qdrant RAG
    """
    user_id    = state.get("user_id", "anonymous")
    session_id = state.get("session_id", "default")

    # ── 1. Session history: Redis first ─────────────────────────────────────
    session_history = await get_session_history(
        user_id=user_id,
        session_id=session_id,
        limit=5,
    )

    # ── 2. Fallback to PostgreSQL if Redis has nothing ───────────────────────
    if not session_history and state.get("session_id"):
        try:
            async with AsyncSessionLocal() as db:
                db_messages = await crud.get_session_messages(db, session_id)
                session_history = [
                    {"role": m.role, "content": m.content}
                    for m in db_messages[-5:]
                ]
                logger.debug(f"Session history loaded from PostgreSQL ({len(session_history)} messages)")
        except Exception as e:
            logger.warning(f"PostgreSQL session history fallback failed: {e}")

    # ── 3. RAG context from Qdrant ───────────────────────────────────────────
    user_context = await retrieve_user_context(
        user_id=user_id,
        query=state.get("user_message", ""),
    )

    return {
        **state,
        "session_history": session_history,
        "user_context":    user_context,
    }


@traceable(name="synthesizer")
async def synthesizer_node(state: CineAgentState) -> CineAgentState:
    """
    Assembles all four agent outputs into one coherent report.
    Uses the synthesizer ChatPromptTemplate.
    """
    prompt_template = build_synthesizer_prompt()

    llm = ChatGroq(
        api_key=settings.groq_api_key,
        model=settings.groq_model,
        temperature=0.5,
        max_tokens=2048,
    )

    # Build the assembled context string fed as the human message
    market_comps_display = state.get("market_comps", [])[:5]  # cap at 5 to save tokens

    assembled_context = "\n\n".join([
        f"USER CONCEPT:\n{state.get('user_message', '')}",

        "═══ SCRIPT ANALYST OUTPUT ═══",
        f"Genres             : {state.get('genres', [])}",
        f"Tone               : {state.get('tone', [])}",
        f"Complexity         : {state.get('structural_complexity', 'N/A')}",
        f"Characters         :\n{json.dumps(state.get('characters', []), indent=2)}",
        f"Themes             : {state.get('themes', [])}",
        f"Budget flags       : {state.get('budget_flags', [])}",
        f"IMDb comps (live)  :\n{json.dumps(state.get('script_comps', []), indent=2)}",

        "═══ BUDGET PLANNER OUTPUT ═══",
        f"Tier               : {state.get('budget_tier', 'N/A')}",
        f"Total estimate     : ${state.get('total_budget_estimate', 0):,.0f}",
        f"Breakdown          :\n{json.dumps(state.get('budget_breakdown', {}), indent=2)}",
        f"Live union rates   :\n{json.dumps(state.get('live_union_rates', {}), indent=2)}",

        "═══ CASTING DIRECTOR OUTPUT ═══",
        f"Suggestions        :\n{json.dumps(state.get('casting_suggestions', []), indent=2)}",
        f"Casting notes      :\n{state.get('casting_notes', '')}",

        "═══ MARKET INTEL OUTPUT ═══",
        f"Comps (top 5)      :\n{json.dumps(market_comps_display, indent=2)}",
        f"Average ROI        : {state.get('avg_roi', 0):.2f}x",
        f"Distribution       : {state.get('distribution_recommendation', 'streaming')}",
        f"Top platform       : {state.get('top_streaming_platform', 'Unknown')}",
        f"Release note       :\n{state.get('release_timing_note', '')}",
    ])

    try:
        messages = prompt_template.format_messages(assembled_context=assembled_context)
        response = await llm.ainvoke(messages)
        report = response.content
    except Exception as e:
        logger.error(f"Synthesizer LLM error: {e}")
        report = (
            f"# CineAgent Pro Report\n\n"
            f"⚠️ Report generation encountered an error: {e}\n\n"
            f"**Raw data collected:**\n\n{assembled_context[:2000]}"
        )

    return {**state, "final_report": report, "error": None}
