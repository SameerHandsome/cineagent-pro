"""
backend/graph/workflow.py
──────────────────────────
Defines the LangGraph StateGraph.

EXECUTION ORDER (A2A-correct):
  context_assembly
      → orchestrator
          → script_analyst          ← runs FIRST (writes genres, characters,
          │                            complexity, budget_flags to state)
          → downstream_fan_out      ← reads script outputs, then fans out:
              ├── budget_planner    ← reads structural_complexity, budget_flags, genres
              ├── casting_director  ← reads characters, budget_tier, genres, tone
              └── market_intel      ← reads genres, budget_tier, themes
          → synthesizer             ← combines all four outputs

WHY script runs first:
  Budget, Casting, and Market agents consume data that Script Analyst
  produces (genres, characters, budget_flags, structural_complexity).
  Running all four in parallel via Send() would give the downstream agents
  an empty state for those fields — defeating A2A entirely.
  Fix: script runs sequentially first, THEN the other three fan out in
  parallel (they don't depend on each other, so parallelism is still gained).
"""
from langgraph.constants import Send
from langgraph.graph import END, StateGraph

from backend.agents.budget_planner import budget_planner_node
from backend.agents.casting_director import casting_director_node
from backend.agents.market_intel import market_intel_node
from backend.agents.orchestrator import orchestrator_node
from backend.agents.script_analyst import script_analyst_node
from backend.graph.nodes import context_assembly_node, synthesizer_node
from backend.graph.state import CineAgentState


def route_downstream(state: CineAgentState) -> list[Send]:
    """
    Called AFTER script_analyst completes.
    Fans out budget, casting, and market agents in parallel.
    Each now has access to script analyst's state outputs via A2A.
    Inactive agents (not in active_agents) are never called.
    """
    active = state.get("active_agents", ["script", "budget", "casting", "market"])
    sends = []
    if "budget" in active:
        sends.append(Send("budget_planner", state))
    if "casting" in active:
        sends.append(Send("casting_director", state))
    if "market" in active:
        sends.append(Send("market_intel", state))

    # If no downstream agents are active (e.g. script_only intent),
    # route directly to synthesizer
    if not sends:
        sends.append(Send("synthesizer", state))

    return sends


def build_workflow() -> StateGraph:
    graph = StateGraph(CineAgentState)

    # ── Register all nodes ────────────────────────────────────────────────────
    graph.add_node("context_assembly",  context_assembly_node)
    graph.add_node("orchestrator",      orchestrator_node)
    graph.add_node("script_analyst",    script_analyst_node)   # stage 1
    graph.add_node("budget_planner",    budget_planner_node)   # stage 2 (parallel)
    graph.add_node("casting_director",  casting_director_node) # stage 2 (parallel)
    graph.add_node("market_intel",      market_intel_node)     # stage 2 (parallel)
    graph.add_node("synthesizer",       synthesizer_node)      # stage 3

    # ── Entry point ───────────────────────────────────────────────────────────
    graph.set_entry_point("context_assembly")

    # ── Sequential spine ──────────────────────────────────────────────────────
    graph.add_edge("context_assembly", "orchestrator")

    # Orchestrator → script_analyst (always runs; it's skipped internally
    # if "script" not in active_agents, returning state unchanged)
    graph.add_edge("orchestrator", "script_analyst")

    # ── A2A fan-out: script outputs now available in state ───────────────────
    graph.add_conditional_edges("script_analyst", route_downstream)

    # ── All parallel stage-2 agents converge at synthesizer ──────────────────
    for agent in ["budget_planner", "casting_director", "market_intel"]:
        graph.add_edge(agent, "synthesizer")

    graph.add_edge("synthesizer", END)

    return graph.compile()


# Module-level compiled graph — initialised once at app startup
workflow = build_workflow()
