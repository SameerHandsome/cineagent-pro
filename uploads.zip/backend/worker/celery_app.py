"""backend/worker/celery_app.py — Celery app configured with Upstash Redis broker."""
from celery import Celery
from backend.config import settings

# Upstash Redis uses rediss:// (SSL). Celery requires ssl_cert_reqs to be
# explicitly set in the URL otherwise it throws ValueError on startup.
# We append ?ssl_cert_reqs=CERT_NONE which tells Celery to use SSL
# without verifying the server certificate — correct for Upstash.
def _fix_redis_ssl(url: str) -> str:
    """Append ssl_cert_reqs=CERT_NONE to rediss:// URLs that don't already have it."""
    if url.startswith("rediss://") and "ssl_cert_reqs" not in url:
        separator = "&" if "?" in url else "?"
        return f"{url}{separator}ssl_cert_reqs=CERT_NONE"
    return url


_broker_url  = _fix_redis_ssl(settings.redis_url)
_backend_url = _fix_redis_ssl(settings.redis_url)

celery_app = Celery(
    "cineagent_worker",
    broker=_broker_url,
    backend=_backend_url,
    include=["backend.worker.tasks"],
)

celery_app.conf.update(
    task_serializer="json",
    result_serializer="json",
    accept_content=["json"],
    timezone="UTC",
    enable_utc=True,
    task_track_started=True,
    broker_connection_retry_on_startup=True,
    broker_use_ssl={
        "ssl_cert_reqs": "CERT_NONE",
    },
    redis_backend_use_ssl={
        "ssl_cert_reqs": "CERT_NONE",
    },
)