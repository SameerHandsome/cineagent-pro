/* frontend/js/chat.js — CineAgent Pro chat interface */

const API   = "http://localhost:8000";
const token = localStorage.getItem("cineagent_token");

// Redirect to login if no token
if (!token) window.location.href = "index.html";

let currentSessionId = null;
let isStreaming      = false;

// ── Markdown renderer (minimal, no library needed) ───────────────────────────
function renderMarkdown(text) {
  return text
    .replace(/^### (.+)$/gm, "<h3>$1</h3>")
    .replace(/^## (.+)$/gm, "<h2>$1</h2>")
    .replace(/^# (.+)$/gm, "<h1>$1</h1>")
    .replace(/\*\*(.+?)\*\*/g, "<strong>$1</strong>")
    .replace(/\*(.+?)\*/g, "<em>$1</em>")
    .replace(/`(.+?)`/g, "<code>$1</code>")
    .replace(/^---$/gm, "<hr>")
    .replace(/^\| (.+) \|$/gm, (_, cells) => {
      const tds = cells.split(" | ").map((c) => `<td>${c}</td>`).join("");
      return `<tr>${tds}</tr>`;
    })
    .replace(/(<tr>.*<\/tr>\n?)+/g, (rows) => `<table>${rows}</table>`)
    .replace(/^\d+\. (.+)$/gm, "<li>$1</li>")
    .replace(/(<li>.*<\/li>\n?)+/g, (items) => `<ol>${items}</ol>`)
    .replace(/^- (.+)$/gm, "<li>$1</li>")
    .replace(/(<li>.*<\/li>\n?)+/g, (items) => `<ul>${items}</ul>`)
    .replace(/\n\n/g, "</p><p>")
    .replace(/^(?!<[h|l|t|u|o|p])/gm, "")
    .replace(/([^>])\n([^<])/g, "$1<br>$2");
}

// ── Auth header ───────────────────────────────────────────────────────────────
function authHeaders(extra = {}) {
  return { Authorization: `Bearer ${token}`, "Content-Type": "application/json", ...extra };
}

// ── Session list ──────────────────────────────────────────────────────────────
async function loadSessions() {
  try {
    const res = await fetch(`${API}/api/sessions`, { headers: authHeaders() });
    if (res.status === 401) { logout(); return; }
    const sessions = await res.json();
    renderSessionList(sessions);
  } catch {
    console.warn("Could not load sessions.");
  }
}

function renderSessionList(sessions) {
  const list = document.getElementById("session-list");
  list.innerHTML = "";

  if (!sessions.length) {
    list.innerHTML = '<li style="padding:12px;font-size:13px;color:var(--text-muted)">No projects yet</li>';
    return;
  }

  sessions.forEach((s) => {
    const li = document.createElement("li");
    li.className = "session-item" + (s.id === currentSessionId ? " active" : "");
    li.textContent = s.title || "Untitled Project";
    li.title       = s.title || "Untitled Project";
    li.addEventListener("click", () => loadSession(s.id, s.title));
    list.appendChild(li);
  });
}

async function loadSession(sessionId, title) {
  currentSessionId = sessionId;
  document.getElementById("session-title").textContent = title || "Project";
  document.getElementById("welcome-screen")?.remove();

  const container = document.getElementById("messages-container");
  container.innerHTML = "";

  try {
    const res = await fetch(`${API}/api/sessions/${sessionId}/messages`, { headers: authHeaders() });
    const messages = await res.json();
    messages.forEach((m) => appendMessage(m.role, m.content, false));
    container.scrollTop = container.scrollHeight;
  } catch {
    console.warn("Could not load messages for session:", sessionId);
  }

  await loadSessions();  // refresh sidebar active state
}

// ── New session ───────────────────────────────────────────────────────────────
document.getElementById("new-session-btn").addEventListener("click", async () => {
  try {
    const res = await fetch(`${API}/api/sessions`, {
      method:  "POST",
      headers: authHeaders(),
    });
    const session = await res.json();
    currentSessionId = session.id;
    document.getElementById("session-title").textContent = "New Project";
    document.getElementById("messages-container").innerHTML = `
      <div class="welcome-screen" id="welcome-screen">
        <div class="welcome-icon">🎬</div>
        <h2>New project</h2>
        <p>Describe your concept to get started.</p>
      </div>`;
    await loadSessions();
  } catch {
    console.warn("Could not create new session.");
  }
});

// ── Append message ─────────────────────────────────────────────────────────────
function appendMessage(role, content, streaming = false) {
  const welcome = document.getElementById("welcome-screen");
  if (welcome) welcome.remove();

  const container = document.getElementById("messages-container");
  const row       = document.createElement("div");
  row.className   = `message-row ${role}`;

  const bubble    = document.createElement("div");
  bubble.className = "message-bubble";

  if (role === "assistant") {
    bubble.innerHTML = streaming ? "" : renderMarkdown(content);
    if (streaming) bubble.classList.add("typing-cursor");
  } else {
    bubble.textContent = content;
  }

  row.appendChild(bubble);
  container.appendChild(row);
  container.scrollTop = container.scrollHeight;
  return bubble;
}

// ── Agent status pills ─────────────────────────────────────────────────────────
const AGENT_PILL_MAP = {
  "AGENT:SCRIPT_ANALYST":    "pill-script",
  "AGENT:BUDGET_PLANNER":    "pill-budget",
  "AGENT:CASTING_DIRECTOR":  "pill-casting",
  "AGENT:MARKET_INTEL":      "pill-market",
};

function setAgentActive(agentKey) {
  const pillId = AGENT_PILL_MAP[agentKey];
  if (!pillId) return;
  const pill = document.getElementById(pillId);
  if (pill) {
    pill.classList.add("active");
    setTimeout(() => {
      pill.classList.remove("active");
      pill.classList.add("complete");
    }, 1500);
  }
}

function resetAgentPills() {
  Object.values(AGENT_PILL_MAP).forEach((id) => {
    const pill = document.getElementById(id);
    if (pill) pill.classList.remove("active", "complete");
  });
}

// ── Send message ──────────────────────────────────────────────────────────────
async function sendMessage(text) {
  if (isStreaming || !text.trim()) return;
  isStreaming = true;

  // Create session on first message if needed
  if (!currentSessionId) {
    try {
      const res = await fetch(`${API}/api/sessions`, {
        method:  "POST",
        headers: authHeaders(),
      });
      const s = await res.json();
      currentSessionId = s.id;
    } catch {
      console.warn("Could not create session.");
    }
  }

  // UI: disable input, show agent bar
  const input   = document.getElementById("message-input");
  const sendBtn = document.getElementById("send-btn");
  input.value   = "";
  input.style.height = "auto";
  sendBtn.disabled   = true;
  updateCharCount(0);

  const statusBar = document.getElementById("agent-status-bar");
  statusBar.classList.remove("hidden");
  resetAgentPills();

  // Append user message immediately
  appendMessage("user", text);

  // Create assistant bubble for streaming
  const assistantBubble = appendMessage("assistant", "", true);
  let   reportBuffer    = "";
  let   inReport        = false;

  try {
    const res = await fetch(`${API}/api/chat`, {
      method:  "POST",
      headers: authHeaders(),
      body:    JSON.stringify({ message: text, session_id: currentSessionId }),
    });

    if (res.status === 429) {
      assistantBubble.classList.remove("typing-cursor");
      assistantBubble.textContent = "⚠️ Rate limit reached. Please wait a moment before sending another message.";
      return;
    }

    if (!res.ok) {
      assistantBubble.classList.remove("typing-cursor");
      assistantBubble.textContent = "⚠️ Error connecting to CineAgent. Is the backend running?";
      return;
    }

    const reader  = res.body.getReader();
    const decoder = new TextDecoder();

    while (true) {
      const { value, done } = await reader.read();
      if (done) break;

      const chunk = decoder.decode(value, { stream: true });
      const lines = chunk.split("\n");

      for (const line of lines) {
        if (!line.startsWith("data: ")) continue;
        const data = line.slice(6);

        if (data === "[DONE]") {
          inReport = false;
          break;
        }

        if (data.startsWith("[ERROR]")) {
          assistantBubble.classList.remove("typing-cursor");
          assistantBubble.innerHTML = `<span style="color:var(--danger)">⚠️ ${data}</span>`;
          return;
        }

        if (data.startsWith("[AGENT:")) {
          const agentKey = data.slice(1, -1); // strip [ ]
          setAgentActive(agentKey);
          continue;
        }

        // Accumulate report text
        reportBuffer += data;
        inReport = true;
        assistantBubble.innerHTML = renderMarkdown(reportBuffer);
        assistantBubble.scrollIntoView({ behavior: "smooth", block: "end" });
      }
    }
  } catch (err) {
    assistantBubble.classList.remove("typing-cursor");
    assistantBubble.textContent = "⚠️ Stream interrupted. Please try again.";
    console.error("Stream error:", err);
  } finally {
    assistantBubble.classList.remove("typing-cursor");
    statusBar.classList.add("hidden");
    isStreaming        = false;
    sendBtn.disabled   = false;
    input.focus();
    await loadSessions();  // refresh sidebar (session title may have updated)
  }
}

// ── Input handling ─────────────────────────────────────────────────────────────
const input   = document.getElementById("message-input");
const sendBtn = document.getElementById("send-btn");

function updateCharCount(len) {
  document.getElementById("char-count").textContent = `${len} / 4000`;
}

input.addEventListener("input", () => {
  // Auto-grow textarea
  input.style.height = "auto";
  input.style.height = Math.min(input.scrollHeight, 160) + "px";

  const len = input.value.length;
  sendBtn.disabled = len === 0 || isStreaming;
  updateCharCount(len);
});

input.addEventListener("keydown", (e) => {
  if (e.key === "Enter" && !e.shiftKey) {
    e.preventDefault();
    if (!sendBtn.disabled) sendMessage(input.value.trim());
  }
});

sendBtn.addEventListener("click", () => sendMessage(input.value.trim()));

// ── Example prompts ────────────────────────────────────────────────────────────
document.addEventListener("click", (e) => {
  if (e.target.classList.contains("example-pill")) {
    const prompt = e.target.dataset.prompt;
    input.value  = prompt;
    updateCharCount(prompt.length);
    sendBtn.disabled = false;
    input.focus();
  }
});

// ── Session search ─────────────────────────────────────────────────────────────
document.getElementById("session-search").addEventListener("input", (e) => {
  const q = e.target.value.toLowerCase();
  document.querySelectorAll(".session-item").forEach((item) => {
    item.style.display = item.textContent.toLowerCase().includes(q) ? "" : "none";
  });
});

// ── Sidebar toggle (mobile) ───────────────────────────────────────────────────
document.getElementById("sidebar-toggle").addEventListener("click", () => {
  document.getElementById("sidebar").classList.toggle("open");
});

// ── Logout ────────────────────────────────────────────────────────────────────
function logout() {
  localStorage.removeItem("cineagent_token");
  window.location.href = "index.html";
}
document.getElementById("logout-btn").addEventListener("click", logout);

// ── Init ──────────────────────────────────────────────────────────────────────
loadSessions();
input.focus();
