"""
mcp_clients/tool_registry.py
─────────────────────────────
After loader.py merges all tools, this module slices them into
agent-specific tool sets.  Agents import ONLY their assigned set,
preventing cross-agent tool misuse and keeping prompts tight.

Tool naming convention:
  • Local tools:   parse_screenplay, extract_characters, etc.
  • Remote tools:  tavily__tavily_search
                   playwright__browser_navigate, playwright__browser_snapshot
                   filesystem__read_file
                   github__search_repositories
"""
import logging
from typing import Any

from langchain_core.tools import BaseTool

logger = logging.getLogger(__name__)

# ── Tool name prefixes/names per agent ────────────────────────────────────────
SCRIPT_TOOL_NAMES = {
    "parse_screenplay",
    "extract_characters",
    "analyze_themes",
    "identify_key_scenes",
    "browser_navigate",    # playwright — IMDb scraping
    "browser_snapshot",    # playwright
}

CASTING_TOOL_NAMES = {
    "search_casting_db",
    "get_casting_preferences",
    "tavily_search",    # live actor news (Tavily) / credits
    "search_repositories", # github — casting datasets
}

BUDGET_TOOL_NAMES = {
    "calculate_budget_line",
    "get_union_rate_from_db",
    "read_file",           # filesystem — user uploaded templates
    "tavily_search",    # live union rate lookups (Tavily)
}

MARKET_TOOL_NAMES = {
    "get_market_comps_from_db",
    "get_streaming_landscape",
    "browser_navigate",    # playwright — Box Office Mojo
    "browser_snapshot",    # playwright
    "tavily_search",    # streaming acquisition news (Tavily)
}


class ToolRegistry:
    """
    Holds the full merged tool list and exposes agent-specific subsets.
    Instantiated once during app startup.
    """

    def __init__(self, all_tools: list[BaseTool]) -> None:
        self._all: dict[str, BaseTool] = {}
        for tool in all_tools:
            # Strip server prefix if present (e.g. "playwright__browser_navigate" → "browser_navigate")
            name = getattr(tool, "name", "")
            short_name = name.split("__")[-1] if "__" in name else name
            self._all[short_name] = tool
            self._all[name] = tool  # also index by full name

        logger.info(f"ToolRegistry initialised with {len(all_tools)} tools")

    def _get_subset(self, names: set[str], agent: str) -> list[BaseTool]:
        subset = []
        missing = []
        for name in names:
            tool = self._all.get(name)
            if tool:
                subset.append(tool)
            else:
                missing.append(name)
        if missing:
            logger.warning(f"[{agent}] Tools unavailable (remote server down?): {missing}")
        return subset

    @property
    def script_tools(self) -> list[BaseTool]:
        return self._get_subset(SCRIPT_TOOL_NAMES, "ScriptAnalyst")

    @property
    def casting_tools(self) -> list[BaseTool]:
        return self._get_subset(CASTING_TOOL_NAMES, "CastingDirector")

    @property
    def budget_tools(self) -> list[BaseTool]:
        return self._get_subset(BUDGET_TOOL_NAMES, "BudgetPlanner")

    @property
    def market_tools(self) -> list[BaseTool]:
        return self._get_subset(MARKET_TOOL_NAMES, "MarketIntel")

    def all_tools(self) -> list[BaseTool]:
        return list({id(t): t for t in self._all.values()}.values())


# ── Module-level singleton — set by FastAPI lifespan ─────────────────────────
registry: ToolRegistry | None = None


def init_registry(tools: list[BaseTool]) -> ToolRegistry:
    global registry
    registry = ToolRegistry(tools)
    return registry


def get_registry() -> ToolRegistry:
    if registry is None:
        raise RuntimeError("ToolRegistry not initialised. Call init_registry() in app startup.")
    return registry
