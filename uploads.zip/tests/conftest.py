"""
tests/conftest.py — shared pytest fixtures.

PATCHING STRATEGY
─────────────────
All agents do:  from mcp_clients.tool_registry import get_registry
This binds `get_registry` into each agent module's own namespace at import time.
Patching `mcp_clients.tool_registry.get_registry` therefore does NOT affect
agents that have already imported it — the classic Python import trap.

Correct fix: patch `backend.agents.<module>.get_registry` — the name in the
module that actually calls it.  We also use create=True so the patch works
even if the module hasn't been imported yet at fixture setup time.
"""
from unittest.mock import AsyncMock, MagicMock, patch

import pytest
import pytest_asyncio

from backend.auth.jwt_handler import create_access_token

# ── App client ────────────────────────────────────────────────────────────────

@pytest_asyncio.fixture
async def client():
    """Async HTTP client wired to the FastAPI app in-process."""
    from httpx import ASGITransport, AsyncClient

    from backend.main import app
    async with AsyncClient(
        transport=ASGITransport(app=app), base_url="http://test"
    ) as ac:
        yield ac


@pytest.fixture
def auth_headers():
    """Valid JWT Bearer headers for a test user."""
    token = create_access_token(user_id="test-user-001", email="test@cineagent.com")
    return {"Authorization": f"Bearer {token}"}


# ── Infrastructure mocks ──────────────────────────────────────────────────────

@pytest.fixture
def mock_redis():
    """Mock Upstash Redis — patched at the source module."""
    with patch("backend.cache.redis_client.get_redis") as mock_get:
        redis = AsyncMock()
        redis.lrange.return_value = []
        redis.rpush.return_value = 1
        redis.ltrim.return_value = True
        redis.expire.return_value = True
        redis.incr.return_value = 1
        redis.get.return_value = None
        redis.set.return_value = True
        mock_get.return_value = redis
        yield redis


@pytest.fixture
def mock_qdrant():
    """Mock Qdrant client — patched at the retriever source."""
    with patch("backend.rag.retriever.get_qdrant") as mock_get:
        client = AsyncMock()
        client.search.return_value = []
        mock_get.return_value = client
        yield client


@pytest.fixture
def mock_tool_registry():
    """
    Mock ToolRegistry.

    WHY we import modules before patching:
      patch("backend.agents.script_analyst.get_registry") only works
      AFTER the module has been imported — otherwise Python doesn't know
      the attribute exists.  We import all agent modules explicitly first,
      then patch the `get_registry` name in each module's namespace.
      create=True is a safety net but the explicit import is what matters.

    WHY we patch each module individually:
      Each agent binds `get_registry` into its own namespace at import time
      via `from mcp_clients.tool_registry import get_registry`.
      Patching the source module does not affect already-bound names.
    """
    # Force all agent modules to be imported so their namespaces exist
    import backend.agents.budget_planner  # noqa: F401
    import backend.agents.casting_director  # noqa: F401
    import backend.agents.market_intel  # noqa: F401
    import backend.agents.script_analyst  # noqa: F401

    mock_registry = MagicMock()
    mock_registry.script_tools  = []
    mock_registry.budget_tools  = []
    mock_registry.casting_tools = []
    mock_registry.market_tools  = []

    with patch("backend.agents.script_analyst.get_registry",   return_value=mock_registry, create=True), \
         patch("backend.agents.budget_planner.get_registry",   return_value=mock_registry, create=True), \
         patch("backend.agents.casting_director.get_registry", return_value=mock_registry, create=True), \
         patch("backend.agents.market_intel.get_registry",     return_value=mock_registry, create=True):
        yield mock_registry


# ── Sample state ──────────────────────────────────────────────────────────────

@pytest.fixture
def sample_state():
    """
    Minimal CineAgentState for agent unit tests.
    Contains every field agents read from state so no KeyError occurs.
    """
    return {
        "user_id":               "test-user-001",
        "session_id":            "test-session-001",
        "user_message":          (
            "A rogue AI on a deep space mining vessel starts making "
            "autonomous decisions to protect the crew."
        ),
        "session_history":       [],
        "user_context":          "User developing sci-fi thriller, $5M budget target.",
        "active_agents":         ["script", "budget", "casting", "market"],
        "genres":                ["sci-fi"],
        "tone":                  ["tense", "dark"],
        "structural_complexity": "moderate",
        "budget_flags":          ["vfx_heavy"],
        "budget_tier":           "indie",
        "characters":            [{"name": "The AI", "description": "Sentient ship AI"}],
        "themes":                ["ai_consciousness", "survival"],
    }


# ── Groq response helper ──────────────────────────────────────────────────────

@pytest.fixture
def mock_groq_response():
    """Factory that builds a fake Groq completion response object."""
    def _make(content: str):
        msg = MagicMock()
        msg.content = content
        msg.tool_calls = []
        choice = MagicMock()
        choice.message = msg
        resp = MagicMock()
        resp.choices = [choice]
        return resp
    return _make
