"""tests/integration/test_auth_api.py — auth endpoint integration tests."""
from unittest.mock import AsyncMock, MagicMock, patch

import pytest


@pytest.mark.asyncio
async def test_register_new_user(client, mock_redis, mock_qdrant):
    """POST /auth/register creates user and returns JWT."""
    mock_user = MagicMock()
    mock_user.id    = "new-user-001"
    mock_user.email = "new@cineagent.com"

    with patch("backend.auth.router.crud.get_user_by_email", AsyncMock(return_value=None)), \
         patch("backend.auth.router.crud.create_user", AsyncMock(return_value=mock_user)):
        resp = await client.post("/auth/register", json={
            "email": "new@cineagent.com",
            "username": "newuser",
            "password": "Str0ngP@ssword!",
        })

    assert resp.status_code == 200
    data = resp.json()
    assert "access_token" in data
    assert data["token_type"] == "bearer"


@pytest.mark.asyncio
async def test_register_duplicate_email_returns_400(client):
    """POST /auth/register with existing email returns 400."""
    existing_user = MagicMock()
    existing_user.email = "taken@cineagent.com"

    with patch("backend.auth.router.crud.get_user_by_email", AsyncMock(return_value=existing_user)):
        resp = await client.post("/auth/register", json={
            "email": "taken@cineagent.com",
            "username": "someone",
            "password": "Password123!",
        })

    assert resp.status_code == 400
    assert "already registered" in resp.json()["detail"]


@pytest.mark.asyncio
async def test_login_valid_credentials(client):
    """POST /auth/login with correct password returns JWT."""
    from passlib.context import CryptContext
    pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")

    mock_user = MagicMock()
    mock_user.id              = "user-001"
    mock_user.email           = "user@cineagent.com"
    mock_user.hashed_password = pwd_context.hash("CorrectPassword!")

    with patch("backend.auth.router.crud.get_user_by_email", AsyncMock(return_value=mock_user)):
        resp = await client.post("/auth/login", json={
            "email": "user@cineagent.com",
            "password": "CorrectPassword!",
        })

    assert resp.status_code == 200
    assert "access_token" in resp.json()


@pytest.mark.asyncio
async def test_login_wrong_password_returns_401(client):
    """POST /auth/login with wrong password returns 401."""
    from passlib.context import CryptContext
    pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")

    mock_user = MagicMock()
    mock_user.id              = "user-001"
    mock_user.email           = "user@cineagent.com"
    mock_user.hashed_password = pwd_context.hash("CorrectPassword!")

    with patch("backend.auth.router.crud.get_user_by_email", AsyncMock(return_value=mock_user)):
        resp = await client.post("/auth/login", json={
            "email": "user@cineagent.com",
            "password": "WrongPassword!",
        })

    assert resp.status_code == 401


@pytest.mark.asyncio
async def test_health_endpoint(client):
    """GET /health returns 200 and status ok."""
    resp = await client.get("/health")
    assert resp.status_code == 200
    assert resp.json()["status"] == "ok"
