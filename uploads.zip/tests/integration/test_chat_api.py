"""
tests/integration/test_chat_api.py
────────────────────────────────────
Integration tests for /api/chat, /api/sessions endpoints.
The entire LangGraph workflow is mocked so tests run without
live Groq / Redis / Qdrant / MCP connections.
"""
from unittest.mock import AsyncMock, MagicMock, patch

import pytest

FINAL_REPORT = "# 🎬 CineAgent Pro Report\n\n## 📖 Project Overview\nTest sci-fi concept."


def _mock_workflow_stream(state: dict):
    """Async generator simulating LangGraph workflow output chunks."""
    async def _gen():
        yield {"script_analyst": {**state, "genres": ["sci-fi"]}}
        yield {"budget_planner": {**state, "budget_tier": "indie"}}
        yield {"synthesizer": {**state, "final_report": FINAL_REPORT}}
    return _gen()


@pytest.mark.asyncio
async def test_chat_requires_auth(client):
    """Chat endpoint rejects requests without a Bearer token."""
    resp = await client.post("/api/chat", json={"message": "test"})
    assert resp.status_code == 401


@pytest.mark.asyncio
async def test_chat_streams_response(client, auth_headers, mock_redis, mock_qdrant, mock_tool_registry):
    """Chat endpoint streams SSE data including agent status and final report."""
    with patch("backend.api.chat.workflow") as mock_wf, \
         patch("backend.api.chat.crud.save_message", AsyncMock()), \
         patch("backend.api.chat.trigger_background_indexing") as mock_task:

        mock_wf.astream = lambda state: _mock_workflow_stream(state)
        mock_task.delay = MagicMock()

        resp = await client.post(
            "/api/chat",
            json={"message": "A rogue AI on a deep space mining vessel."},
            headers=auth_headers,
        )

    assert resp.status_code == 200
    assert "text/event-stream" in resp.headers["content-type"]
    body = resp.text
    assert "AGENT:SCRIPT_ANALYST" in body or "AGENT:SYNTHESIZER" in body or FINAL_REPORT[:20] in body


@pytest.mark.asyncio
async def test_chat_rate_limited(client, auth_headers):
    """Chat endpoint returns 429 when rate limit is exceeded."""
    with patch("backend.api.chat.check_rate_limit", AsyncMock(return_value=False)):
        resp = await client.post(
            "/api/chat",
            json={"message": "test"},
            headers=auth_headers,
        )
    assert resp.status_code == 429


@pytest.mark.asyncio
async def test_list_sessions_requires_auth(client):
    resp = await client.get("/api/sessions")
    assert resp.status_code == 401


@pytest.mark.asyncio
async def test_list_sessions_returns_list(client, auth_headers):
    mock_session = MagicMock()
    mock_session.id = "sess-001"
    mock_session.title = "Sci-Fi Project"
    mock_session.updated_at = "2024-01-01T00:00:00"

    with patch("backend.api.chat.crud.get_user_sessions", AsyncMock(return_value=[mock_session])):
        resp = await client.get("/api/sessions", headers=auth_headers)

    assert resp.status_code == 200
    data = resp.json()
    assert isinstance(data, list)
    assert data[0]["id"] == "sess-001"


@pytest.mark.asyncio
async def test_create_session(client, auth_headers):
    mock_session = MagicMock()
    mock_session.id = "sess-new-001"
    mock_session.title = "Untitled Project"

    with patch("backend.api.chat.crud.create_session", AsyncMock(return_value=mock_session)):
        resp = await client.post("/api/sessions", headers=auth_headers)

    assert resp.status_code == 200
    assert resp.json()["id"] == "sess-new-001"


@pytest.mark.asyncio
async def test_get_session_messages(client, auth_headers):
    from datetime import datetime, timezone
    mock_msg = MagicMock()
    mock_msg.role = "user"
    mock_msg.content = "Hello CineAgent"
    mock_msg.created_at = datetime(2024, 1, 1, tzinfo=timezone.utc)

    with patch("backend.api.chat.crud.get_session_messages", AsyncMock(return_value=[mock_msg])):
        resp = await client.get("/api/sessions/sess-001/messages", headers=auth_headers)

    assert resp.status_code == 200
    messages = resp.json()
    assert messages[0]["role"] == "user"
    assert messages[0]["content"] == "Hello CineAgent"
