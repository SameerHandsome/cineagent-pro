"""
tests/integration/test_worker.py
──────────────────────────────────
Integration tests for Celery background tasks.
Uses eager mode — tasks run synchronously in the test process
without a real broker, so no Redis/Celery server needed.
"""
from unittest.mock import AsyncMock, MagicMock, patch

import pytest


@pytest.fixture
def settings():
    """Dummy fixture so celery_eager has something to depend on."""
    yield


@pytest.fixture(autouse=True)
def celery_eager(settings):
    """Run all Celery tasks synchronously (no broker needed)."""
    from backend.worker.celery_app import celery_app
    celery_app.conf.task_always_eager = True
    celery_app.conf.task_eager_propagates = True
    yield
    celery_app.conf.task_always_eager = False


def test_trigger_background_indexing_calls_qdrant():
    """Background indexing task generates summary and indexes to Qdrant."""
    with patch("backend.worker.tasks._run_async") as mock_run:
        mock_run.return_value = None

        from backend.worker.tasks import trigger_background_indexing
        trigger_background_indexing(
            user_id="user-001",
            session_id="sess-001",
            user_message="A rogue AI on a mining vessel.",
            assistant_report="# Report\n\nSci-fi, indie budget, streaming.",
        )

    mock_run.assert_called_once()


def test_trigger_background_indexing_retries_on_failure():
    """Background task retries up to max_retries on failure."""
    with patch("backend.worker.tasks._run_async", side_effect=Exception("Groq timeout")):
        from backend.worker.tasks import trigger_background_indexing

        with pytest.raises(Exception):
            trigger_background_indexing.apply(
                args=["user-001", "sess-001", "message", "report"],
                retries=2,
            )


@pytest.mark.asyncio
async def test_generate_and_index_creates_summary():
    """_generate_and_index calls Groq and indexes both summary and preference."""
    mock_groq_resp = MagicMock()
    mock_groq_resp.choices[0].message.content = "Sci-fi thriller, indie, streaming."

    mock_summary = AsyncMock()
    mock_pref = AsyncMock()

    with patch("backend.worker.tasks.AsyncGroq") as MockGroq, \
         patch("backend.rag.indexer.index_session_summary", mock_summary), \
         patch("backend.rag.indexer.index_user_preference", mock_pref):

        MockGroq.return_value.chat.completions.create = AsyncMock(return_value=mock_groq_resp)

        from backend.worker.tasks import _generate_and_index
        await _generate_and_index(
            user_id="user-001",
            session_id="sess-001",
            user_message="A rogue AI on a mining vessel protecting the crew.",
            assistant_report="## Budget\n\n$4.2M indie budget.",
            genres=["sci-fi"],
        )

    mock_summary.assert_called_once()
    mock_pref.assert_called_once()

    summary_call = mock_summary.call_args
    assert summary_call[1]["user_id"] == "user-001"
    assert summary_call[1]["genres"] == ["sci-fi"]
