"""tests/unit/test_agents.py — unit tests for all agent nodes."""
import json
from unittest.mock import AsyncMock, MagicMock, patch

import pytest
from langchain_core.messages import AIMessage

# ── Orchestrator ──────────────────────────────────────────────────────────────

@pytest.mark.asyncio
async def test_orchestrator_full_analysis(sample_state, mock_redis, mock_qdrant):
    """Orchestrator correctly routes a logline to all four agents."""
    mock_response = MagicMock()
    mock_response.content = json.dumps({
        "intent": "full_analysis",
        "active_agents": ["script", "budget", "casting", "market"]
    })

    with patch("backend.agents.orchestrator.ChatGroq") as MockLLM:
        MockLLM.return_value.ainvoke = AsyncMock(return_value=mock_response)
        from backend.agents.orchestrator import orchestrator_node
        result = await orchestrator_node(sample_state)

    assert result["active_agents"] == ["script", "budget", "casting", "market"]
    assert result["intent"] == "full_analysis"


@pytest.mark.asyncio
async def test_orchestrator_budget_only(sample_state, mock_redis, mock_qdrant):
    """Orchestrator routes a budget-only question to only budget agent."""
    state = {**sample_state, "user_message": "What would a 30-day shoot cost in SAG?"}
    mock_response = MagicMock()
    mock_response.content = json.dumps({
        "intent": "budget_only",
        "active_agents": ["budget"]
    })

    with patch("backend.agents.orchestrator.ChatGroq") as MockLLM:
        MockLLM.return_value.ainvoke = AsyncMock(return_value=mock_response)
        from backend.agents.orchestrator import orchestrator_node
        result = await orchestrator_node(state)

    assert result["active_agents"] == ["budget"]


@pytest.mark.asyncio
async def test_orchestrator_json_parse_failure_defaults(sample_state, mock_redis, mock_qdrant):
    """Orchestrator falls back to full analysis on JSON parse failure."""
    mock_response = MagicMock()
    mock_response.content = "This is not JSON at all"

    with patch("backend.agents.orchestrator.ChatGroq") as MockLLM:
        MockLLM.return_value.ainvoke = AsyncMock(return_value=mock_response)
        from backend.agents.orchestrator import orchestrator_node
        result = await orchestrator_node(sample_state)

    assert set(result["active_agents"]) == {"script", "budget", "casting", "market"}


# ── Script Analyst ────────────────────────────────────────────────────────────

@pytest.mark.asyncio
async def test_script_analyst_skipped_when_not_active(sample_state, mock_tool_registry):
    """Script analyst skips gracefully when not in active_agents."""
    state = {**sample_state, "active_agents": ["budget"]}
    from backend.agents.script_analyst import script_analyst_node
    result = await script_analyst_node(state)
    assert result == state  # state unchanged


@pytest.mark.asyncio
async def test_script_analyst_parses_json_output(sample_state, mock_tool_registry, mock_redis, mock_qdrant):
    """Script analyst correctly parses structured JSON from LLM response."""
    expected_json = {
        "genres": ["sci-fi"],
        "tone": ["tense", "dark"],
        "structural_complexity": "moderate",
        "characters": [{"name": "AI", "description": "sentient ship AI"}],
        "themes": ["ai_consciousness"],
        "budget_flags": ["vfx_heavy"],
        "script_comps": []
    }
    mock_response = MagicMock()
    mock_response.content = json.dumps(expected_json)
    mock_response.tool_calls = []

    with patch("backend.agents._base.ChatGroq") as MockLLM:
        MockLLM.return_value.bind_tools.return_value = MockLLM.return_value
        MockLLM.return_value.ainvoke = AsyncMock(return_value=mock_response)
        from backend.agents.script_analyst import script_analyst_node
        result = await script_analyst_node(sample_state)

    assert result["genres"] == ["sci-fi"]
    assert result["structural_complexity"] == "moderate"
    assert result["budget_flags"] == ["vfx_heavy"]


# ── Budget Planner ────────────────────────────────────────────────────────────

@pytest.mark.asyncio
async def test_budget_planner_skipped_when_not_active(sample_state, mock_tool_registry):
    state = {**sample_state, "active_agents": ["script"]}
    from backend.agents.budget_planner import budget_planner_node
    result = await budget_planner_node(state)
    assert result == state


@pytest.mark.asyncio
async def test_budget_planner_accumulates_tool_results(sample_state, mock_tool_registry, mock_redis, mock_qdrant):
    """Budget planner accumulates calculate_budget_line results into breakdown."""
    state = {
        **sample_state,
        "genres": ["sci-fi"],
        "structural_complexity": "moderate"
    }

    tool_result = {
        "department": "production",
        "department_total": 1_200_000.0,
        "budget_tier": "indie",
        "line_items": {"grip_electric": 800_000, "locations": 400_000},
        "complexity_used": "moderate",
        "shoot_days": 35,
    }

    # Simulate what run_agent_loop returns: (final_content_str, tool_results_list)
    fake_final_content = json.dumps({
        "budget_breakdown": {"production": tool_result},
        "total_budget_estimate": 1_200_000.0,
        "budget_tier": "indie"
    })
    fake_tool_results = [
        {"tool": "calculate_budget_line", "args": {}, "result": tool_result}
    ]

    mock_tool = MagicMock()
    mock_tool.name = "calculate_budget_line"
    mock_registry_instance = MagicMock()
    mock_registry_instance.budget_tools = [mock_tool]

    with patch("mcp_clients.tool_registry.get_registry", return_value=mock_registry_instance), \
         patch("backend.agents.budget_planner.run_agent_loop",
               AsyncMock(return_value=(fake_final_content, fake_tool_results))):
        from backend.agents.budget_planner import budget_planner_node
        result = await budget_planner_node(state)

    assert "production" in result["budget_breakdown"]
    assert result["total_budget_estimate"] == 1_200_000.0
    assert result["budget_tier"] == "indie"

@pytest.mark.asyncio
async def test_market_intel_distribution_inference(sample_state, mock_tool_registry, mock_redis, mock_qdrant):
    """Market intel correctly infers 'streaming' from LLM output text."""
    mock_response = MagicMock()
    mock_response.content = "This film is best suited for streaming distribution via Netflix."
    mock_response.tool_calls = []

    with patch("backend.agents._base.ChatGroq") as MockLLM:
        MockLLM.return_value.bind_tools.return_value = MockLLM.return_value
        MockLLM.return_value.ainvoke = AsyncMock(return_value=mock_response)
        from backend.agents.market_intel import market_intel_node
        result = await market_intel_node(sample_state)

    assert result["distribution_recommendation"] == "streaming"
