"""tests/unit/test_auth.py — JWT and auth utility tests."""
import pytest

from backend.auth.jwt_handler import create_access_token, decode_token


def test_token_round_trip():
    token = create_access_token("user-123", "test@example.com")
    payload = decode_token(token)
    assert payload["sub"] == "user-123"
    assert payload["email"] == "test@example.com"


def test_invalid_token_raises():
    with pytest.raises(ValueError, match="Invalid token"):
        decode_token("this.is.not.valid")


def test_tampered_token_raises():
    token = create_access_token("user-123", "test@example.com")
    tampered = token[:-5] + "AAAAA"
    with pytest.raises(ValueError):
        decode_token(tampered)
