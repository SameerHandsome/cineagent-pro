"""tests/unit/test_cache.py — Redis cache and rate limiting tests."""
import json
from unittest.mock import AsyncMock, MagicMock, patch

import pytest


@pytest.mark.asyncio
async def test_save_and_get_session_history():
    """Messages saved to Redis are retrievable."""
    stored: list[bytes] = []

    mock_redis = AsyncMock()
    mock_redis.rpush = AsyncMock(side_effect=lambda k, v: stored.append(v.encode() if isinstance(v, str) else v))
    mock_redis.ltrim = AsyncMock(return_value=True)
    mock_redis.expire = AsyncMock(return_value=True)
    mock_redis.lrange = AsyncMock(return_value=[
        json.dumps({"role": "user", "content": "Test message"}).encode()
    ])

    with patch("backend.cache.redis_client.get_redis", return_value=mock_redis):
        from backend.cache.redis_client import get_session_history, save_message
        await save_message("user1", "sess1", "user", "Test message")
        history = await get_session_history("user1", "sess1", limit=5)

    assert len(history) == 1
    assert history[0]["role"] == "user"
    assert history[0]["content"] == "Test message"


@pytest.mark.asyncio
async def test_get_session_history_returns_empty_on_error():
    """get_session_history returns [] when Redis raises an exception."""
    mock_redis = AsyncMock()
    mock_redis.lrange = AsyncMock(side_effect=Exception("Redis connection failed"))

    with patch("backend.cache.redis_client.get_redis", return_value=mock_redis):
        from backend.cache.redis_client import get_session_history
        history = await get_session_history("user1", "sess1")

    assert history == []


@pytest.mark.asyncio
async def test_rate_limit_allows_under_threshold():
    """Rate limiter allows requests below the threshold."""
    mock_redis = AsyncMock()
    mock_redis.incr = AsyncMock(return_value=5)   # 5th request
    mock_redis.expire = AsyncMock(return_value=True)

    with patch("backend.cache.redis_client.get_redis", return_value=mock_redis):
        from backend.cache.redis_client import check_rate_limit
        allowed = await check_rate_limit("user1", window_seconds=60, max_requests=10)

    assert allowed is True


@pytest.mark.asyncio
async def test_rate_limit_blocks_over_threshold():
    """Rate limiter blocks requests above the threshold."""
    mock_redis = AsyncMock()
    mock_redis.incr = AsyncMock(return_value=11)  # 11th request, limit=10
    mock_redis.expire = AsyncMock(return_value=True)

    with patch("backend.cache.redis_client.get_redis", return_value=mock_redis):
        from backend.cache.redis_client import check_rate_limit
        allowed = await check_rate_limit("user1", window_seconds=60, max_requests=10)

    assert allowed is False


@pytest.mark.asyncio
async def test_tool_cache_hit():
    """Cached tool result is returned without calling the tool again."""
    cached_result = {"comps": [{"title": "Ex Machina", "budget": 15_000_000}]}

    mock_redis = AsyncMock()
    mock_redis.get = AsyncMock(return_value=json.dumps(cached_result))

    with patch("backend.cache.redis_client.get_redis", return_value=mock_redis):
        from backend.cache.redis_client import get_cached_tool_result
        result = await get_cached_tool_result("get_market_comps_from_db", {"genre": "sci-fi"})

    assert result == cached_result


@pytest.mark.asyncio
async def test_tool_cache_miss_returns_none():
    """Cache miss returns None so the tool is called normally."""
    mock_redis = AsyncMock()
    mock_redis.get = AsyncMock(return_value=None)

    with patch("backend.cache.redis_client.get_redis", return_value=mock_redis):
        from backend.cache.redis_client import get_cached_tool_result
        result = await get_cached_tool_result("get_market_comps_from_db", {"genre": "sci-fi"})

    assert result is None
