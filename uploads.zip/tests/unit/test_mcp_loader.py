"""
tests/unit/test_mcp_loader.py — MCP loader and tool registry tests.

PATCHING :
  `mcp_clients.loader` uses langchain_mcp_adapters which is optional in CI.
  We import the module explicitly first so the patch target exists, then
  patch MultiServerMCPClient before the function under test calls it.
"""
from unittest.mock import AsyncMock, MagicMock, patch

import pytest

# ── Force loader module import before any patching ────────────────────────────
# loader.py is not imported by mcp_clients/__init__.py (intentional — it
# requires langchain_mcp_adapters which may not be installed).
# Tests that need loader must import it directly.

def _import_loader():
    try:
        import mcp_clients.loader as loader_module  # noqa: F401
        return loader_module
    except ImportError as e:
        pytest.skip(f"langchain_mcp_adapters not installed — skipping loader tests: {e}")


@pytest.mark.asyncio
async def test_local_tools_load_on_success():
    """Loader returns tools when local MCP server is reachable."""
    loader = _import_loader()

    mock_tool = MagicMock()
    mock_tool.name = "parse_screenplay"

    with patch.object(loader, "MultiServerMCPClient") as MockClient:
        MockClient.return_value.get_tools = AsyncMock(return_value=[mock_tool])
        tools = await loader._load_local_tools()

    assert len(tools) == 1
    assert tools[0].name == "parse_screenplay"


@pytest.mark.asyncio
async def test_local_tools_return_empty_on_failure():
    """Loader returns empty list when local MCP server is unreachable."""
    loader = _import_loader()

    with patch.object(loader, "MultiServerMCPClient") as MockClient:
        MockClient.return_value.get_tools = AsyncMock(side_effect=ConnectionError("refused"))
        tools = await loader._load_local_tools()

    assert tools == []


@pytest.mark.asyncio
async def test_load_all_tools_deduplicates():
    """load_all_tools deduplicates tools with identical names."""
    loader = _import_loader()

    tool_a = MagicMock()
    tool_a.name = "tavily_search"

    tool_b = MagicMock()
    tool_b.name = "tavily_search"   # duplicate

    tool_c = MagicMock()
    tool_c.name = "parse_screenplay"

    with patch.object(loader, "_load_local_tools",  AsyncMock(return_value=[tool_a, tool_c])), \
         patch.object(loader, "_load_remote_tools", AsyncMock(return_value=[tool_b])):
        tools = await loader.load_all_tools()

    names = [t.name for t in tools]
    assert names.count("tavily_search") == 1
    assert "parse_screenplay" in names


def test_tool_registry_agent_slicing():
    """ToolRegistry correctly slices tools per agent."""
    from mcp_clients.tool_registry import ToolRegistry

    tools = []
    for name in ["parse_screenplay", "tavily_search", "calculate_budget_line", "search_casting_db"]:
        t = MagicMock()
        t.name = name
        tools.append(t)

    registry = ToolRegistry(tools)
    script_names  = {t.name for t in registry.script_tools}
    budget_names  = {t.name for t in registry.budget_tools}
    casting_names = {t.name for t in registry.casting_tools}

    assert "parse_screenplay"        in script_names
    assert "calculate_budget_line"   in budget_names
    assert "search_casting_db"       in casting_names


def test_tool_registry_missing_tool_logged(caplog):
    """ToolRegistry logs a warning for unavailable tools and doesn't crash."""
    import logging

    from mcp_clients.tool_registry import ToolRegistry

    t = MagicMock()
    t.name = "parse_screenplay"
    registry = ToolRegistry([t])

    with caplog.at_level(logging.WARNING):
        tools = registry.budget_tools   # budget tools not in registry

    assert isinstance(tools, list)
