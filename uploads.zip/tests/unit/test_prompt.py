"""tests/unit/test_prompt.py — Prompt template structure and assembly tests."""
import pytest
from langchain_core.messages import AIMessage, HumanMessage, SystemMessage, ToolMessage
from langchain_core.prompts import ChatPromptTemplate


def _get_message_types(messages: list) -> list[str]:
    return [type(m).__name__ for m in messages]


# ── Template structure ────────────────────────────────────────────────────────

def test_orchestrator_prompt_has_correct_variables():
    from backend.prompt.templates import build_orchestrator_prompt
    prompt = build_orchestrator_prompt()
    assert set(prompt.input_variables) == {"rag_context", "session_history", "user_query"}


def test_script_analyst_prompt_has_agent_scratchpad():
    from backend.prompt.templates import build_script_analyst_prompt
    prompt = build_script_analyst_prompt()
    assert "agent_scratchpad" in prompt.input_variables
    assert "rag_context" in prompt.input_variables
    assert "session_history" in prompt.input_variables
    assert "user_query" in prompt.input_variables


def test_budget_planner_prompt_has_a2a_variables():
    """Budget planner template must include A2A context from Script Analyst."""
    from backend.prompt.templates import build_budget_planner_prompt
    prompt = build_budget_planner_prompt()
    required = {"structural_complexity", "budget_flags", "genres", "shoot_days",
                "rag_context", "session_history", "user_query", "agent_scratchpad"}
    assert required.issubset(set(prompt.input_variables))


def test_casting_director_prompt_has_a2a_variables():
    from backend.prompt.templates import build_casting_director_prompt
    prompt = build_casting_director_prompt()
    required = {"characters", "budget_tier", "genres", "tone",
                "rag_context", "session_history", "user_query", "agent_scratchpad"}
    assert required.issubset(set(prompt.input_variables))


def test_market_intel_prompt_has_a2a_variables():
    from backend.prompt.templates import build_market_intel_prompt
    prompt = build_market_intel_prompt()
    required = {"genres", "budget_tier", "themes",
                "rag_context", "session_history", "user_query", "agent_scratchpad"}
    assert required.issubset(set(prompt.input_variables))


def test_synthesizer_prompt_has_assembled_context():
    from backend.prompt.templates import build_synthesizer_prompt
    prompt = build_synthesizer_prompt()
    assert "assembled_context" in prompt.input_variables


# ── Prompt assembly order ─────────────────────────────────────────────────────

def test_script_analyst_prompt_assembly_order():
    """
    Verifies the correct assembly order:
      [1] SystemMessage  (system prompt with RAG + session history baked in)
      [2] agent_scratchpad messages (empty at start, grows during tool loop)
      [3] HumanMessage   (user query)
    """
    from backend.prompt.templates import build_script_analyst_prompt
    prompt = build_script_analyst_prompt()

    messages = prompt.format_messages(
        rag_context="User previously worked on a horror film.",
        session_history="USER: What genres work for low budget?\nASSISTANT: Horror and thriller.",
        agent_scratchpad=[],   # empty at start of first iteration
        user_query="A rogue AI on a mining vessel.",
    )

    types = _get_message_types(messages)
    assert types[0] == "SystemMessage",  "First message must be SystemMessage"
    assert types[-1] == "HumanMessage",  "Last message must be HumanMessage (user query)"


def test_rag_context_injected_into_system_message():
    """RAG context from Qdrant appears in the system message content."""
    from backend.prompt.templates import build_script_analyst_prompt
    prompt = build_script_analyst_prompt()

    rag_context = "User previously developed a $3M sci-fi short targeting festivals."
    messages = prompt.format_messages(
        rag_context=rag_context,
        session_history="No prior messages.",
        agent_scratchpad=[],
        user_query="Space horror concept.",
    )

    system_content = messages[0].content
    assert rag_context in system_content, "RAG context must be in system message"


def test_session_history_injected_into_system_message():
    """Last 5 messages from Redis appear in the system message content."""
    from backend.prompt.templates import build_script_analyst_prompt
    prompt = build_script_analyst_prompt()

    session_history = "USER: Can we keep budget under 5M?\nASSISTANT: Yes, target indie tier."
    messages = prompt.format_messages(
        rag_context="No prior history.",
        session_history=session_history,
        agent_scratchpad=[],
        user_query="Refine the concept.",
    )

    system_content = messages[0].content
    assert session_history in system_content, "Session history must be in system message"


def test_tool_calls_in_scratchpad_are_inserted_between_system_and_human():
    """
    When agent_scratchpad has tool call/result messages,
    they appear BETWEEN the system message and the human query.
    """
    from backend.prompt.templates import build_budget_planner_prompt

    scratchpad = [
        AIMessage(content="", additional_kwargs={"tool_calls": [{"id": "t1", "name": "calculate_budget_line", "args": {}}]}),
        ToolMessage(content='{"department_total": 500000}', tool_call_id="t1"),
    ]

    prompt = build_budget_planner_prompt()
    messages = prompt.format_messages(
        structural_complexity="moderate",
        budget_flags="['vfx_heavy']",
        genres="['sci-fi']",
        shoot_days="35",
        rag_context="No prior history.",
        session_history="No prior messages.",
        agent_scratchpad=scratchpad,
        user_query="What does this cost?",
    )

    types = _get_message_types(messages)
    assert types[0]  == "SystemMessage"
    assert types[-1] == "HumanMessage"
    # Tool messages should be sandwiched between system and human
    assert "AIMessage" in types[1:-1]
    assert "ToolMessage" in types[1:-1]
