"""
tests/unit/test_rag.py — RAG embedder, retriever, and indexer tests.

MOCK STRATEGY
─────────────
• embed() calls SentenceTransformer which downloads a model from HuggingFace.
  In CI / restricted networks this fails.  All tests that call code which
  uses embed() must patch it.

• Retriever and indexer tests patch backend.rag.embedder.embed so the
  production code path (retriever.py calls embed()) is intercepted before
  any network call.

• Qdrant client (get_qdrant) is patched at the source module level.
"""
from unittest.mock import AsyncMock, MagicMock, patch

import pytest

# A fake 384-dim vector returned by all embed() mocks
FAKE_VECTOR = [0.1] * 384


# ══════════════════════════════════════════════════════════════════════════════
# EMBEDDER — unit tests that mock the model download
# ══════════════════════════════════════════════════════════════════════════════

def test_embed_returns_list_of_floats():
    """embed() returns a flat list of 384 floats."""
    import numpy as np

    mock_model = MagicMock()
    mock_model.encode.return_value = np.array(FAKE_VECTOR)

    with patch("backend.rag.embedder.get_embedder", return_value=mock_model):
        # Clear lru_cache so our mock is used
        from backend.rag import embedder as emb_mod
        from backend.rag.embedder import embed
        emb_mod.get_embedder.cache_clear()

        with patch("backend.rag.embedder.SentenceTransformer", return_value=mock_model):
            vector = embed("A sci-fi thriller about a rogue AI")

    assert isinstance(vector, list)
    assert len(vector) == 384
    assert all(isinstance(v, float) for v in vector)


def test_embed_batch_returns_list_of_vectors():
    """embed_batch() returns one 384-dim vector per input text."""
    import numpy as np

    texts = ["Sci-fi film", "Horror thriller", "Romantic drama"]
    mock_model = MagicMock()
    mock_model.encode.return_value = np.array([FAKE_VECTOR] * len(texts))

    with patch("backend.rag.embedder.SentenceTransformer", return_value=mock_model):
        from backend.rag import embedder as emb_mod
        emb_mod.get_embedder.cache_clear()

        from backend.rag.embedder import embed_batch
        vectors = embed_batch(texts)

    assert len(vectors) == 3
    assert all(len(v) == 384 for v in vectors)


# ══════════════════════════════════════════════════════════════════════════════
# RETRIEVER — multi-tenancy isolation tests
# ══════════════════════════════════════════════════════════════════════════════

@pytest.mark.asyncio
async def test_retrieve_always_filters_by_tenant_id():
    """Every Qdrant search call MUST include tenant_id in its filter."""
    mock_client = AsyncMock()
    mock_client.search = AsyncMock(return_value=[])

    # Patch both embed (no network) and Qdrant client
    with patch("backend.rag.retriever.get_qdrant", return_value=mock_client), \
         patch("backend.rag.retriever.embed", return_value=FAKE_VECTOR):
        from backend.rag.retriever import retrieve_user_context
        await retrieve_user_context("user-abc", "sci-fi thriller")

    mock_client.search.assert_called_once()
    call_args = mock_client.search.call_args
    # Support both positional and keyword argument styles
    search_filter = (
        call_args.kwargs.get("query_filter")
        or (call_args.args[2] if len(call_args.args) > 2 else None)
    )
    assert search_filter is not None, "Qdrant search must include a query_filter"
    tenant_condition = next(
        (c for c in search_filter.must if c.key == "tenant_id"), None
    )
    assert tenant_condition is not None, "tenant_id MUST be in search filter"
    assert tenant_condition.match.value == "user-abc"


@pytest.mark.asyncio
async def test_retrieve_anonymous_user_returns_safe_default():
    """Anonymous sessions never touch Qdrant — return a safe default string."""
    mock_client = AsyncMock()

    with patch("backend.rag.retriever.get_qdrant", return_value=mock_client), \
         patch("backend.rag.retriever.embed", return_value=FAKE_VECTOR):
        from backend.rag.retriever import retrieve_user_context
        result = await retrieve_user_context("anonymous", "query")

    mock_client.search.assert_not_called()
    assert "anonymous" in result.lower() or "no prior" in result.lower()


@pytest.mark.asyncio
async def test_retrieve_with_doc_type_filter():
    """When doc_type is specified, it is included as a MUST filter condition."""
    mock_client = AsyncMock()
    mock_client.search = AsyncMock(return_value=[])

    with patch("backend.rag.retriever.get_qdrant", return_value=mock_client), \
         patch("backend.rag.retriever.embed", return_value=FAKE_VECTOR):
        from backend.rag.retriever import retrieve_user_context
        await retrieve_user_context("user-abc", "query", doc_type="session_summary")

    call_args = mock_client.search.call_args
    search_filter = (
        call_args.kwargs.get("query_filter")
        or (call_args.args[2] if len(call_args.args) > 2 else None)
    )
    must_keys = [c.key for c in search_filter.must]
    assert "tenant_id" in must_keys
    assert "doc_type"  in must_keys


@pytest.mark.asyncio
async def test_retrieve_different_users_get_different_filters():
    """Two separate users produce different tenant_id filter values."""
    mock_client = AsyncMock()
    mock_client.search = AsyncMock(return_value=[])

    with patch("backend.rag.retriever.get_qdrant", return_value=mock_client), \
         patch("backend.rag.retriever.embed", return_value=FAKE_VECTOR):
        from backend.rag.retriever import retrieve_user_context
        await retrieve_user_context("user-AAA", "sci-fi query")
        await retrieve_user_context("user-BBB", "sci-fi query")

    assert mock_client.search.call_count == 2
    calls = mock_client.search.call_args_list

    def _get_filter(call):
        return (
            call.kwargs.get("query_filter")
            or (call.args[2] if len(call.args) > 2 else None)
        )

    filter_a = _get_filter(calls[0])
    filter_b = _get_filter(calls[1])

    tenant_a = next(c for c in filter_a.must if c.key == "tenant_id").match.value
    tenant_b = next(c for c in filter_b.must if c.key == "tenant_id").match.value

    assert tenant_a == "user-AAA"
    assert tenant_b == "user-BBB"
    assert tenant_a != tenant_b


@pytest.mark.asyncio
async def test_retrieve_formats_results_with_labels():
    """Retrieved results are formatted with doc_type emoji labels and score."""
    mock_result = MagicMock()
    mock_result.score = 0.92
    mock_result.payload = {
        "tenant_id":  "user1",
        "doc_type":   "session_summary",
        "title":      "Space Mining Thriller",
        "summary":    "User developing $5M sci-fi thriller targeting Netflix.",
        "topic":      "sci-fi",
    }

    mock_client = AsyncMock()
    mock_client.search = AsyncMock(return_value=[mock_result])

    with patch("backend.rag.retriever.get_qdrant", return_value=mock_client), \
         patch("backend.rag.retriever.embed", return_value=FAKE_VECTOR):
        from backend.rag.retriever import retrieve_user_context
        context = await retrieve_user_context("user1", "sci-fi space thriller")

    assert "Space Mining Thriller" in context
    assert "Netflix" in context
    assert "🎬" in context   # session_summary label


@pytest.mark.asyncio
async def test_retrieve_handles_qdrant_failure_gracefully():
    """Returns safe fallback string — never raises — when Qdrant is unreachable."""
    mock_client = AsyncMock()
    mock_client.search = AsyncMock(side_effect=Exception("Qdrant connection refused"))

    with patch("backend.rag.retriever.get_qdrant", return_value=mock_client), \
         patch("backend.rag.retriever.embed", return_value=FAKE_VECTOR):
        from backend.rag.retriever import retrieve_user_context
        context = await retrieve_user_context("user1", "query")

    assert "unavailable" in context.lower()


# ══════════════════════════════════════════════════════════════════════════════
# INDEXER — multi-tenancy storage tests
# ══════════════════════════════════════════════════════════════════════════════

@pytest.mark.asyncio
async def test_index_session_summary_stores_tenant_id():
    """Indexer stores tenant_id (NOT user_id) + doc_type + topic in payload."""
    mock_client = AsyncMock()
    mock_client.get_collections = AsyncMock(return_value=MagicMock(collections=[
        MagicMock(name="cineagent_sessions")
    ]))
    mock_client.create_payload_index = AsyncMock()
    mock_client.upsert = AsyncMock()

    with patch("backend.rag.indexer.get_qdrant", return_value=mock_client), \
         patch("backend.rag.indexer.embed", return_value=FAKE_VECTOR):
        from backend.rag.indexer import index_session_summary
        await index_session_summary(
            user_id="user-001",
            session_id="sess-001",
            session_title="Space Thriller",
            summary="Sci-fi, indie budget, targeting streaming.",
            genres=["sci-fi"],
        )

    mock_client.upsert.assert_called_once()
    points = mock_client.upsert.call_args.kwargs["points"]
    payload = points[0].payload

    assert payload["tenant_id"] == "user-001"
    assert "user_id" not in payload            # old field must be gone
    assert payload["doc_type"] == "session_summary"
    assert payload["topic"]    == "sci-fi"


@pytest.mark.asyncio
async def test_index_user_preference_stores_correct_doc_type():
    """Preference indexer stores doc_type='user_preference' and correct topic."""
    mock_client = AsyncMock()
    mock_client.get_collections = AsyncMock(return_value=MagicMock(collections=[
        MagicMock(name="cineagent_sessions")
    ]))
    mock_client.create_payload_index = AsyncMock()
    mock_client.upsert = AsyncMock()

    with patch("backend.rag.indexer.get_qdrant", return_value=mock_client), \
         patch("backend.rag.indexer.embed", return_value=FAKE_VECTOR):
        from backend.rag.indexer import index_user_preference
        await index_user_preference(
            user_id="user-001",
            preference_text="Prefers streaming over theatrical for indie budgets.",
            topic="sci-fi",
        )

    mock_client.upsert.assert_called_once()
    points = mock_client.upsert.call_args.kwargs["points"]
    payload = points[0].payload

    assert payload["tenant_id"] == "user-001"
    assert payload["doc_type"]  == "user_preference"
    assert payload["topic"]     == "sci-fi"


def test_extract_topic_uses_genres_first():
    """_extract_topic prefers explicit genres list over keyword scanning."""
    from backend.rag.indexer import _extract_topic
    assert _extract_topic("Any summary text", genres=["horror"]) == "horror"


def test_extract_topic_scans_summary_when_no_genres():
    """_extract_topic keyword-scans the summary when genres are not provided."""
    from backend.rag.indexer import _extract_topic
    assert _extract_topic("A space station where an AI robot turns sentient") == "sci-fi"


def test_ensure_collection_creates_payload_indexes():
    """ensure_collection creates keyword indexes for tenant_id, doc_type, and topic."""
    import asyncio
    mock_client = AsyncMock()
    mock_client.get_collections = AsyncMock(return_value=MagicMock(collections=[
        MagicMock(name="cineagent_sessions")
    ]))
    mock_client.create_payload_index = AsyncMock()

    with patch("backend.rag.indexer.get_qdrant", return_value=mock_client):
        from backend.rag.indexer import ensure_collection
        asyncio.run(ensure_collection())

    indexed_fields = [
        call.kwargs.get("field_name") or call.args[1]
        for call in mock_client.create_payload_index.call_args_list
    ]
    assert "tenant_id" in indexed_fields
    assert "doc_type"  in indexed_fields
    assert "topic"     in indexed_fields
